# MiChatGUI
主要代码从yihong0618/xiaogpt库fork而来  
使用PyQt5封装了小米音箱连接ChatGPT的客户端，代码大量参考了yihong0618/xiaogpt库的代码,  
稍微做修改简化，然后使用Pyqt5将代码封装为桌面软件，方便不会编程的人使用 
打包好的win10二级制程序下载地址如下：  
链接：https://pan.baidu.com/s/1GB2NZW51Fd7jyp_Zx-lk7w  提取码：vcnj       

连接ChatGPT提供两种方式：  
1 使用OpenAI Key的方式  
2 在用户服务代码框内按照规则输入公开免费的HTTP API访问，可以查看我的教程学习如何不用科学上网搭建一个自己的GPT API  
使用方法：  
在软件的输入参数中输入  
(1)用户ID  
(2)账户密码  
(3)型号(型号在音箱底部标签获取，例如L15A)  
(4) 选择连接方式  
(5) 点击开始按钮  
(6) 开始与音箱对话  

代码中的MiChatGUI_Baidu.py文件是小米音箱调用文心一言的例子  
下面的链接可以下载我打包好的windows端的应用程序可以直接使用
链接：https://pan.baidu.com/s/1M5hGJcUCgFfAeCF736xy8g   
提取码：ed1j  

参考代码：  
yihong0618/xiaogpt  
https://github.com/yihong0618/xiaogpt  
